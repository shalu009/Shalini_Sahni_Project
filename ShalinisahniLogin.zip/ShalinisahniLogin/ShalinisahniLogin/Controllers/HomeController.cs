﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShalinisahniLogin.DbContextFile;
using ShalinisahniLogin.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace ShalinisahniLogin.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(IFormCollection form)
        {
            string name = form["Name"];
            string fatherName = form["FatherName"];
            string mobileNumber = form["MobileNumber"];
            string email = form["Email"];
            string dob = form["DOB"];
            string password = form["Password"];
            string role = form["Role"];

            if (string.IsNullOrEmpty(password))
            {
                password = HashPassword("12345"); 
            }

            if (string.IsNullOrEmpty(role))
            {
                role = "User";
            }

            if (ModelState.IsValid)
            {
                var existingUser = await _context.applicants
                    .FirstOrDefaultAsync(u => u.MobileNumber == mobileNumber);

                if (existingUser == null)
                {
                    var applicant = new Applicant
                    {
                        Name = name,
                        FatherName = fatherName,
                        MobileNumber = mobileNumber,
                        Email = email,
                        DOB = DateTime.Parse(dob), 
                        password = password,
                        Role = role
                    };

                    _context.applicants.Add(applicant);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Login");
                }

                ModelState.AddModelError("", "User with this mobile number already exists.");
            }
            else
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine(error.ErrorMessage);
                }
            }

            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string mobileNumber, string password)
        {
            var user = await _context.applicants
                .FirstOrDefaultAsync(u => u.MobileNumber == mobileNumber);

            if (user != null && VerifyPassword(password, user.password))
            {
                bool isAdmin = string.Equals(user.Role, "admin", StringComparison.OrdinalIgnoreCase);
                string redirectUrl = isAdmin ? Url.Action("AdminDashboard") : Url.Action("Profile", new { id = user.Id });

                return Json(new { success = true, redirectTo = redirectUrl });
            }
            return Json(new { success = false, message = "Invalid login attempt." });
        }

        public IActionResult Profile(int id)
        {
            var user = _context.applicants.Find(id);
            return View(user);
        }
        public IActionResult AdminDashboard()
        {
            var users = _context.applicants.ToList();
            return View(users);
        }
        public async Task<IActionResult> ChangePassword (int id,string newPassword)
        {
            var users = await _context.applicants.FindAsync(id);
            if(User != null)
            {
                users.password = HashPassword(newPassword);
                _context.applicants.Update(users);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Profile", new { id = id });
        }
        [HttpPost]
        public async Task<IActionResult> UpdateProfile(
            string Name,
            string FatherName,
            string Email,
            DateTime DOB,
            IFormFile ProfilePicture,
            int Id)
        {
            if (ModelState.IsValid)
            {
                var applicant = await _context.applicants.FindAsync(Id);
                if (applicant == null)
                {
                    return NotFound();
                }

                applicant.Name = Name;
                applicant.FatherName = FatherName;
                applicant.Email = Email;
                applicant.DOB = DOB;

              
                _context.applicants.Update(applicant);
                await _context.SaveChangesAsync();
                return Ok(); 
            }

            return BadRequest(); 
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        private bool VerifyPassword(string password, string storedHash)
        {
            var hash = HashPassword(password);
            return hash == storedHash;
        }
    }
}
